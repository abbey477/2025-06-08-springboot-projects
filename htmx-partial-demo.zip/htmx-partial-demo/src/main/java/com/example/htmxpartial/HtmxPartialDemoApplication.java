package com.example.htmxpartial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtmxPartialDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(HtmxPartialDemoApplication.class, args);
    }
}
