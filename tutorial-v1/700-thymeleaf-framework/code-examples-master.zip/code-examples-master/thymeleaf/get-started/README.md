# How to use Thymeleaf with Spring Boot

For step-by-step instructions, please check out [blog post](https://attacomsian.com/blog/spring-boot-thymeleaf-example).
