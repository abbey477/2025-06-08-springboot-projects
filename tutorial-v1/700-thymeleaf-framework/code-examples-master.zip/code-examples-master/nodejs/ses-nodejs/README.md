# Sending Emails using Amazon SES in Node.js

For step-by-step instructions, please visit the [blog post](https://attacomsian.com/blog/amazon-ses-integration-nodejs).
