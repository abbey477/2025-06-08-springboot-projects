# How to convert XML to JSON in Node.js

For step-by-step instructions, please visit the [blog post](https://attacomsian.com/blog/nodejs-convert-xml-to-json).
