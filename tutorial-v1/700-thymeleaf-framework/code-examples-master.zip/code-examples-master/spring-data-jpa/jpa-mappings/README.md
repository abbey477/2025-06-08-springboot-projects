# Spring Data JPA Relationship Mapping Articles

- [Spring Data JPA One To One Relationship Mapping Example](https://attacomsian.com/blog/spring-data-jpa-one-to-one-mapping)
- [Spring Data JPA One To Many Relationship Mapping Example](https://attacomsian.com/blog/spring-data-jpa-one-to-many-mapping)
- [Spring Data JPA Many To Many Relationship Mapping Example](https://attacomsian.com/blog/spring-data-jpa-many-to-many-mapping)
- [Spring Data JPA Composite Primary Key Mapping Example](https://attacomsian.com/blog/spring-data-jpa-composite-primary-key)