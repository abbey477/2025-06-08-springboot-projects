# Accessing Data with Spring Data JPA and MySQL

For step-by-step instructions, please check out [blog post](https://attacomsian.com/blog/accessing-data-spring-data-jpa-mysql).
