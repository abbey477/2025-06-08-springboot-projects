# Spring Data JPA Query Creation Articles

- [Derived Query Methods in Spring Data JPA](https://attacomsian.com/blog/derived-query-methods-spring-data-jpa)
- [Spring Data JPA Custom Queries with the @Query Annotation](https://attacomsian.com/blog/spring-data-jpa-query-annotation)
- [How to Use Spring Data JPA Named Queries](https://attacomsian.com/blog/spring-data-jpa-named-queries)
