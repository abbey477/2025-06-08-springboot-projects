# Spring Data JPA with H2 DataBase and Spring Boot

For step-by-step instructions, please check out [blog post](https://attacomsian.com/blog/spring-data-jpa-h2-database).
