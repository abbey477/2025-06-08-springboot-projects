# Spring Boot Console Application

For step-by-step instructions, please visit the [blog post](
https://attacomsian.com/blog/spring-boot-console-application).
